<?php
define("USERNAME", "noreply@hris.frontlinebusiness.com.ph");
define("PASSWORD", "b@11551gfN4b");
define("FROM", "Frontline Business Solutions, Inc.");
define("VERIFY_ACCOUNT", "Account Verification");
define("MEMO", "Important Memo: Action Items Needed");
define("PENDING_OT_REQUEST", "Pending Overtime Request");
define("PENDING_LEAVE_REQUEST", "Pending Leave Request");
define("APPROVED_OT_REQUEST", "Approved Overtime Request");
define("APPROVED_LEAVE_REQUEST", "Approved Leave Request");
define("CANCELLED_LEAVE_REQUEST", "Cancelled Leave Request");
define("DECLINED_LEAVE_REQUEST", "Declined Leave Request");
define("DECLINED_OVERTIME_REQUEST", "Declined Overtime Request");
define("RESET_PASSWORD", "Reset Password");
define("VERIFY_EMAIL", "Email Verification");

// local
define("ROOT_DOMAIN", "http://127.0.0.1:5173");
define("IMAGES_URL", "http://127.0.0.1:5173/img");

// online
// define("ROOT_DOMAIN", "https://local-hr.frontlinebusiness.com.ph");
// define("IMAGES_URL", "https://local-hr.frontlinebusiness.com.ph/img");
